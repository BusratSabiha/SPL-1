#include<stdio.h>
//using namespace std;

int relation_matrix[200][200];
char color[200];
int parent_idx[200];
int d[200];
int edge,vertex;

void initialize()
{
    int i,j;
  for(i=0;i<vertex;i++)
            for(j=0;j<vertex;j++)
        {
            relation_matrix[i][j]=0;
        }

        for(i=0;i<vertex;i++){

        color[i]='w';
        parent_idx[i]=-1;
        d[i]=1000000;
        }

}

void build_matrix(int edge)
{

    int i;
    for(i=0; i<edge; i++)
    {
        int u,v;
        printf("enter u & v");
        scanf("%d %d",&u,&v);

        relation_matrix[u][v]=1;
        relation_matrix[v][u]=1;
    }



}

    int main(void)
    {
        //freopen("bfs_input.txt","r",stdin);
        int i;


        printf("how many edge the graph have?");
        scanf("%d",&edge);

        printf("how many vertex you wanna insert?");
        scanf("%d",&vertex);

        initialize();

        build_matrix(edge);

        //get the source node
        int sourcenode;
        printf("enter the index of the source node");
        scanf("%d",&sourcenode);

        int q[vertex];
        int s,e=0;//end-> inserting data in queue.
        q[e]=sourcenode;
        e++;
        color[sourcenode]='g';
        d[sourcenode]=0;
        parent_idx[sourcenode]=-1;


        while((e-s)>0)
        {
            int u=q[s];

            for(i=0; i<vertex; i++)
            {
                int v=i;

                if(relation_matrix[u][v]==1&&color[v]=='w')
                {
                    q[e]=v;
                    e++;
                    color[v]='g';
                    d[v]=d[u]+1;
                    parent_idx[v]=u;
                }
            }
            s++;//dequeue
            color[u]='b';
        }

        printf("\n\n\n");

        for(i=0; i<vertex; i++)

        {
            printf("vertex %d:\t",i);
            printf("level is %d\t",d[i]);
            printf("parent is %d\t",parent_idx[i]);
            printf("color is %c\t",color[i]);
            printf("\n\n\n");

        }





    }


