#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
#include<dos.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>


int relation_matrix[200][200];
char color[200];
int parent_idx[200];
int dist[200];
int index=0;
int vertex,edge;
int result[200];



int x,y,rad=10;

struct node
{
    int parda;
    int qanna;
};

void tostring(char str[],int num)
{
    int rem,len=0,n;
    n=num;

    while(n!=0)
    {
        len++;
        n/=10;
    }

    for(int jal=0; jal<len; jal++)
    {
        rem=num%10;
        num=num/10;
        str[len-(jal+1)]=rem+'0';
    }

    str[len]='\0';
}


void changeColor(int x,int y,int co)
{

    /*graphdefaults();
    cleardevice();*/

    setfillstyle(SOLID_FILL,co);
    circle(x,y,rad);
    floodfill(x,y,WHITE);
}




void build_matrix(int edge,struct node pos[])
{

    int i;
    for(i=0; i<edge; i++)
    {
        int u,v;
        printf("enter u & v");
        scanf("%d %d",&u,&v);

        relation_matrix[u][v]=1;
        relation_matrix[v][u]=1;
        line(pos[u].parda,pos[u].qanna,pos[v].parda,pos[v].qanna);

    }



}

    int main(void)
    {
        int i,j,inna;


        printf("how many edge the graph have?");
        scanf("%d",&edge);

        printf("how many vertex you wanna insert?");
        scanf("%d",&vertex);

        struct node pos[vertex];

        for(i=0;i<vertex;i++)
            for(j=0;j<vertex;j++)
        {
            relation_matrix[i][j]=0;
        }

        for(i=0;i<vertex;i++){

        color[i]='w';
        parent_idx[i]=-1;
        dist[i]=1000000;
        }


     /********************************************************************************************************************/

            int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");


    for(inna=0; inna<vertex; inna++)
    {

        char str[20];
        tostring(str,inna+1);

        if((inna+1)%2==0)
        {
            x=pow(inna+3,2);
            y=x*(inna+1);
            /*x=x+(x/2);
            y=y+(y/5);*/
        }


        else
        {
            x=pow(inna+16,2);
            y=x;
        }
        outtextxy(x-20,y,str);
        /*circle(x,y,rad);


        setfillstyle(SOLID_FILL,WHITE);
        floodfill(x,y,WHITE);*/

        changeColor(x,y,WHITE);

        pos[inna].parda=x;
        pos[inna].qanna=y;
    }

      build_matrix(edge,pos);


       /****************************************************************************************************************/


        //get the source node
        int sourcenode;
        printf("enter the index of the source node");
        scanf("%d",&sourcenode);

        graphdefaults();
        cleardevice();


    for(inna=0; inna<vertex; inna++)
    {

        char str[20];
        tostring(str,inna+1);

        if((inna+1)%2==0)
        {
            x=pow(inna+3,2);
            y=x*(inna+1);
            /*x=x+(x/2);
            y=y+(y/5);*/
        }


        else
        {
            x=pow(inna+16,2);
            y=x;
        }
        outtextxy(x-20,y,str);
        /*circle(x,y,rad);


        setfillstyle(SOLID_FILL,WHITE);
        floodfill(x,y,WHITE);*/

        if(inna==sourcenode)changeColor(x,y,GREEN);

        else changeColor(x,y,WHITE);

        pos[inna].parda=x;
        pos[inna].qanna=y;
    }


    for(i=0;i<vertex;i++)
    {
       for(inna=0;inna<vertex;inna++)
       {
           if(relation_matrix[i][inna]==1)line(pos[i].parda,pos[i].qanna,pos[inna].parda,pos[inna].qanna);
       }
    }


    /*int ki;
    printf("enter ki\n");
    scanf("%d",ki);*/

    Sleep(3000);






/**************************************************************************************************************/




        int queue[vertex];
        result[vertex];
        int start=0;
        queue[start]=sourcenode;
        //+start++;
        color[sourcenode]='g';
        dist[sourcenode]=0;
        parent_idx[sourcenode]=-1;


        while((start)>=0)
            {

                 cleardevice();
                graphdefaults();

            int u=queue[start];

            result[index]=u;
            index++;
            int count=0;
            for(i=0; i<vertex; i++)
            {
                int v=i;

                if(relation_matrix[u][v]==1&&color[v]=='w')
                {
                    start++;
                    queue[start]=v;
                    //end++;
                    color[v]='g';
                    dist[v]=dist[u]+1;
                    parent_idx[v]=u;
                    count++;
                    break;
                }
            }
            if(count==0){

                color[u]='b';
                start--;

            }
            //start++;
           //color[u]='b';


             for(inna=0; inna<vertex; inna++)
    {

        char str[20];
        tostring(str,inna+1);

        if((inna+1)%2==0)
        {
            x=pow(inna+3,2);
            y=x*(inna+1);
            /*x=x+(x/2);
            y=y+(y/5);*/
        }


        else
        {
            x=pow(inna+16,2);
            y=x;
        }
        outtextxy(x-20,y,str);
        /*circle(x,y,rad);


        setfillstyle(SOLID_FILL,WHITE);
        floodfill(x,y,WHITE);*/

        if(color[inna]=='b')changeColor(x,y,RED);
        else if(color[inna]=='g')changeColor(x,y,GREEN);
        else changeColor(x,y,WHITE);



        pos[inna].parda=x;
        pos[inna].qanna=y;
    }


    for(i=0;i<vertex;i++)
    {
       for(inna=0;inna<vertex;inna++)
       {
           if(relation_matrix[i][inna]==1)line(pos[i].parda,pos[i].qanna,pos[inna].parda,pos[inna].qanna);
       }
    }


    //int ki;
    /*printf("enter ki\n");
    scanf("%d",ki);*/

    Sleep(3000);






        }


        for(i=0; i<vertex; i++)
        {

            printf(" %d\t",i);
            printf("distance is %d\t",dist[i]);
            printf("parent is %d\t",parent_idx[i]);
            printf("color is %c\t",color[i]);
            printf("\n\n\n");

        }





    }



