#include<bits/stdc++.h>
using namespace std;
#include<graphics.h>
#include<math.h>


int main(void)
{

    int i;
     int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");

    for(i=0;i<5;i++)
    {
        int x=240;
        int y=320;
        int rad=50;

        circle(x,y,rad);
        if(i%2==0)
        {
            setfillstyle(SOLID_FILL,WHITE);
            floodfill(x,y,WHITE);

        }
        else{
       setfillstyle(SOLID_FILL,RED);
      floodfill(x,y,WHITE);

        }
    }


    getch();
    closegraph();
    return 0;
}

