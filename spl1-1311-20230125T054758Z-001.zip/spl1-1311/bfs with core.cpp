
#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
#include<conio.h>
#include<dos.h>
#include<stdlib.h>

int rad=10,count1=0,vertex[10],rel_matrix[10][10];

struct node
{
    int p;
    int q;
};

void tostring(char str[],int num)
{
    int rem,len=0,n;
    n=num;

    while(n!=0)
    {
        len++;
        n/=10;
    }

    for(int jal=0; jal<len; jal++)
    {
        rem=num%10;
        num=num/10;
        str[len-(jal+1)]=rem+'0';
    }

    str[len]='\0';
}



void changeColor(int x,int y,int col,struct node pos[])
{
    char str[5];
    count1++;
    tostring(str,count1);
    outtextxy(x-25,y,str);
    // graphdefaults();
    //cleardevice();

    pos[count1].p=x;
    pos[count1].q=y;

    setfillstyle(SOLID_FILL,col);
    circle(x,y,rad);
    floodfill(x,y,WHITE);
}

int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");

    int n=10,i,j;
    struct node position[n];

    int col=WHITE;

    changeColor(400,200,col,position);
    changeColor(180,100,col,position);
    changeColor(50,190,col,position);
    changeColor(240,320,col,position);
    changeColor(350,100,col,position);
    changeColor(500,300,col,position);
    changeColor(450,100,col,position);
    changeColor(50,50,col,position);
    changeColor(150,200,col,position);
    changeColor(340,220,col,position);


    line(position[4].p,position[4].q,position[6].p,position[6].q);
    line(position[4].p,position[4].q,position[10].p,position[10].q);
    line(position[4].p,position[4].q,position[9].p,position[9].q);
    line(position[4].p,position[4].q,position[3].p,position[3].q);
    line(position[1].p,position[1].q,position[6].p,position[6].q);
    line(position[7].p,position[7].q,position[6].p,position[6].q);
    line(position[10].p,position[10].q,position[6].p,position[6].q);
    line(position[4].p,position[4].q,position[6].p,position[6].q);


    /*for(i=0;i<5;i++)
    {
        scanf("%d",&c);
     if(c==1)changeColor(4);
       else if(c==2)changeColor(2);
       else changeColor(14);


    }*/




    getch();
    closegraph();



}

