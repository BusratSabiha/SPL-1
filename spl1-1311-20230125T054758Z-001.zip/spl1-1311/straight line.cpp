#include<graphics.h>
int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    line(100,150,200,300);
    getch();
    closegraph();
    return 0;
}
