#include<bits/stdc++.h>
using namespace std;
#include<graphics.h>
#include<math.h>
#include<string.h>
struct node
{
    int parda;
    int qanna;
};

void tostring(char str[],int num)
{
    int rem,len=0,n;
    n=num;

    while(n!=0)
    {
        len++;
        n/=10;
    }

    for(int jal=0; jal<len; jal++)
    {
        rem=num%10;
        num=num/10;
        str[len-(jal+1)]=rem+'0';
    }

    str[len]='\0';
}


int relation_matrix[200][200];
char color[200];
int parent_idx[200];
int dist[200];
int edge,vertex,u,v;

void initialize()
{
    int i,j;
    for(i=1; i<=vertex; i++)
        for(j=1; j<=vertex; j++)
        {
            relation_matrix[i][j]=0;
        }

    for(i=1; i<=vertex; i++)
    {

        color[i]='w';
        parent_idx[i]=-1;
        dist[i]=10000;
    }

}

void build_matrix(int edge,struct node pos[])
{

    int i;
    for(i=0; i<edge; i++)
    {
        //int u,v;
        printf("enter u & v");
        scanf("%d %d",&u,&v);

        relation_matrix[u][v]=1;
        relation_matrix[v][u]=1;

        line(pos[u].parda,pos[u].qanna,pos[v].parda,pos[v].qanna);
    }



}

int main(void)
{
    //freopen("bfs_input.txt","r",stdin);
    int i;
    int inna,x,y,rad=10;


    printf("how many edge the graph have?\n");
    scanf("%d",&edge);

    printf("how many vertex you wanna insert?\n");
    scanf("%d",&vertex);

    struct node pos[vertex];

    initialize();

    /************************************************************************************************/

    int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");


    for(inna=1; inna<=vertex; inna++)
    {

        char str[20];
        tostring(str,inna);

        if(inna%2==0)
        {
            x=pow(inna+2,2);
            y=x*inna;
            /*x=x+(x/2);
            y=y+(y/5);*/
        }


        else
        {
            x=pow(inna+15,2);
            y=x;
        }
        outtextxy(x-20,y,str);
        circle(x,y,rad);


        setfillstyle(SOLID_FILL,WHITE);
        floodfill(x,y,WHITE);

        pos[inna].parda=x;
        pos[inna].qanna=y;
    }

    /*******************************************************************************************************************/

    build_matrix(edge,pos);

    //get the source node
    int sourcenode;
    printf("enter the index of the source node\n");
    scanf("%d",&sourcenode);

    /***************************************************************/

    graphdefaults();
    cleardevice();


    //for sorcenode






    char str[20];

    for(inna=1; inna<=vertex; inna++)
    {

        tostring(str,inna);

        if(inna!=sourcenode)
        {


            if(inna%2==0)
            {
                x=pow(inna+2,2);
                y=x*inna;
                /*x=x+(x/2);
                y=y+(y/5);*/
            }


            else
            {
                x=pow(inna+15,2);
                y=x;
            }
            outtextxy(x-20,y,str);
            circle(x,y,rad);


            setfillstyle(SOLID_FILL,WHITE);
            floodfill(x,y,WHITE);


        }

        else
        {


            if(inna%2==0)
            {
                x=pow(inna+2,2);
                y=x*inna;
                /*x=x+(x/2);
                y=y+(y/5);*/
            }


            else
            {
                x=pow(inna+15,2);
                y=x;
            }
            outtextxy(x-20,y,str);
            circle(x,y,rad);


            setfillstyle(SOLID_FILL,BLUE);
            floodfill(x,y,WHITE);


        }

        pos[inna].parda=x;
        pos[inna].qanna=y;

    }

    for(i=1; i<=vertex; i++)
    {
        for(int hmm=1; hmm<=vertex; hmm++)
        {
            if(relation_matrix[i][hmm]==1||relation_matrix[hmm][i]==1)
            {
                line(pos[i].parda,pos[i].qanna,pos[hmm].parda,pos[hmm].qanna);
            }
        }






    }



    int queue[vertex];
    int start,end=1;//end-> inserting data in queue.
    queue[end]=sourcenode;
    end++;
    color[sourcenode]='g';
    dist[sourcenode]=0;
    parent_idx[sourcenode]=-1;
    int index=1;

    while((end-start)>1)
    {
        int u=queue[start];



        for(i=1; i<=vertex; i++)
        {
            int v=i;

            if(relation_matrix[u][v]==1&&color[v]=='w')
            {
                queue[end]=v;
                end++;
                color[v]='g';
                dist[v]=dist[u]+1;
                parent_idx[v]=u;


            }
        }


        start++;//dequeue
        color[u]='b';

         graphdefaults();
         cleardevice();


    //for sorcenode






    //char str[20];

    for(inna=1; inna<=vertex; inna++)
    {

        tostring(str,inna);

        if(color[inna]=='b')
        {


            if(inna%2==0)
            {
                x=pow(inna+2,2);
                y=x*inna;
                /*x=x+(x/2);
                y=y+(y/5);*/
            }


            else
            {
                x=pow(inna+15,2);
                y=x;
            }
            outtextxy(x-20,y,str);
            circle(x,y,rad);


            setfillstyle(SOLID_FILL,GREEN);
            floodfill(x,y,WHITE);


        }

        else if(color[inna]=='g')
        {


            if(inna%2==0)
            {
                x=pow(inna+2,2);
                y=x*inna;
                /*x=x+(x/2);
                y=y+(y/5);*/
            }


            else
            {
                x=pow(inna+15,2);
                y=x;
            }
            outtextxy(x-20,y,str);
            circle(x,y,rad);


            setfillstyle(SOLID_FILL,BLUE);
            floodfill(x,y,WHITE);


        }

        else{


            if(inna%2==0)
            {
                x=pow(inna+2,2);
                y=x*inna;
                /*x=x+(x/2);
                y=y+(y/5);*/
            }


            else
            {
                x=pow(inna+15,2);
                y=x;
            }
            outtextxy(x-20,y,str);
            circle(x,y,rad);


            setfillstyle(SOLID_FILL,WHITE);
            floodfill(x,y,WHITE);

        }

        pos[inna].parda=x;
        pos[inna].qanna=y;

    }

    for(i=1; i<=vertex; i++)
    {
        for(int hmm=1; hmm<=vertex; hmm++)
        {
            if(relation_matrix[i][hmm]==1||relation_matrix[hmm][i]==1)
            {
                line(pos[i].parda,pos[i].qanna,pos[hmm].parda,pos[hmm].qanna);
            }
        }






    }



    }

    /*printf("\n\n\n");

    for(i=1; i<=vertex; i++)

    {
        printf("vertex %d:\t",i);
        printf("level is %d\t",dist[i]);
        printf("parent is %d\t",parent_idx[i]);
        printf("color is %c\t",color[i]);
        printf("\n\n\n");

    }*/

    getch();
    closegraph();
    return 0;



}

