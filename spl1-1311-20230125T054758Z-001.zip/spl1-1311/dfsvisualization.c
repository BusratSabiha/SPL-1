#include<stdio.h>

int relation_matrix[200][200];
char color[200];
int parent_idx[200];
int distance[200];
int index=0;
int result[200];
void build_matrix(int edge)
{

    int i;
    for(i=0; i<edge; i++)
    {
        int u,v;
        printf("enter u & v");
        scanf("%d %d",&u,&v);

        relation_matrix[u][v]=1;
        relation_matrix[v][u]=1;

    }



}

    int main(void)
    {
        int n,i,edge,j;


        printf("how many edge the graph have?");
        scanf("%d",&edge);

        printf("how many vertex you wanna insert?");
        scanf("%d",&n);

        for(i=0;i<n;i++)
            for(j=0;j<n;j++)
        {
            relation_matrix[i][j]=0;
        }

        for(i=0;i<n;i++){

        color[i]='w';
        parent_idx[i]=-1;
        distance[i]=1000000;
        }



        build_matrix(edge);

        //get the source node
        int sourcenode;
        printf("enter the index of the source node");
        scanf("%d",&sourcenode);

        int queue[n];
        result[n];
        int start=0;
        queue[start]=sourcenode;
        //+start++;
        color[sourcenode]='g';
        distance[sourcenode]=0;
        parent_idx[sourcenode]=-1;


        while((start)>=0)
        {
            int u=queue[start];

            result[index]=u;
            index++;
            int count=0;
            for(i=0; i<n; i++)
            {
                int v=i;

                if(relation_matrix[u][v]==1&&color[v]=='w')
                {
                    start++;
                    queue[start]=v;
                    //end++;
                    color[v]='g';
                    distance[v]=distance[u]+1;
                    parent_idx[v]=u;
                    count++;
                    break;
                }
            }
            if(count==0){

                color[u]='b';
                start--;

            }
            //start++;
           //color[u]='b';
        }


        for(i=0; i<n; i++)
        {

            printf(" %d\t",i);
            printf("distance is %d\t",distance[i]);
            printf("parent is %d\t",parent_idx[i]);
            printf("color is %c\t",color[i]);
            printf("\n\n\n");

        }





    }



