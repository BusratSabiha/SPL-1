#include<graphics.h>



int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    lineto(100,150);
    getch();
    closegraph();
    return 0;
}

