#include<graphics.h>
#include<bits/stdc++.h>
using namespace std;
#include<conio.h>
#include<dos.h>
#include<stdlib.h>

void changeColor(int x)
{
    graphdefaults();
    cleardevice();

    setfillstyle(SOLID_FILL,x);
    circle(300,200,100);
    floodfill(301,201,WHITE);
}

int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");
    changeColor(0);

    int c,i;


     for(i=0;i<5;i++)
     {
         scanf("%d",&c);
      if(c==1)changeColor(4);
        else if(c==2)changeColor(2);
        else changeColor(14);


     }




    getch();
    closegraph();



}

