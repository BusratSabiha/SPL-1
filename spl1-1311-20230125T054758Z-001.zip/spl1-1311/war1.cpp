#include<graphics.h>
int main(void)
{
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");
    getch();
    closegraph();
    return 0;
}
