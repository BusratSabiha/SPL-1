#include<iostream>
using namespace std;

#include<graphics.h>



int main(void)

{
    int n,i;
    int x=100,y=150;

    cout<<"enter n";
    cin>>n;
    int gd=DETECT,gm;
    initgraph(&gd,&gm,"");

    for(i=0;i<n;i++)
    {
        int p,q;
        cout<<"enter p & q";
        cin>>p>>q;

        lineto(x,y);
        x=x+p;
        y=y+q;
    }
    //cout<<"the line is here"<<endl;
    //lineto(300,500);
    getch();
    closegraph();
    return 0;
}

