#include<bits/stdc++.h>
using namespace std;
#include<graphics.h>
#include<math.h>
#include<string.h>

int jal;
struct node
{
    int parda;
    int qanna;
};

void tostring(char str[],int num)
{
    int rem,len=0,n;
    n=num;

    while(n!=0)
    {
        len++;
        n/=10;
    }

    for(jal=0;jal<len;jal++)
    {
        rem=num%10;
        num=num/10;
        str[len-(jal+1)]=rem+'0';
    }

    str[len]='\0';
}

int main(void)
{
    int vertex,inna,x,y,rad=10,edge;

     printf("enter the number of node\n");
    scanf("%d",&vertex);

   struct node pos[vertex];

    int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");


    for(inna=1; inna<=vertex; inna++)
    {

         char str[20];
         tostring(str,inna);

    if(inna%2==0){x=pow(inna+2,2);
       y=x*inna;
    /*x=x+(x/2);
    y=y+(y/5);*/
    }


    else{
        x=pow(inna+15,2);
        y=x;
    }
      outtextxy(x-20,y,str);
      circle(x,y,rad);


      setfillstyle(SOLID_FILL,WHITE);
      floodfill(x,y,WHITE);

      pos[inna].parda=x;
      pos[inna].qanna=y;
    }

    printf("enter the number of edge\n");
    scanf("%d",&edge);

    for(jal=0;jal<edge;jal++)
    {
        int l,m;
        printf("enter the connected node");
        scanf("%d",&l);
        scanf("%d",&m);
        line(pos[l].parda,pos[l].qanna,pos[m].parda,pos[m].qanna);
    }

    graphdefaults();
    cleardevice();
    int bal;x=1;y=1;
    printf("enter inna");
    scanf("%d",&bal);
    if(bal%2==0){x=pow(bal+2,2);
       y=x*bal;
    /*x=x+(x/2);
    y=y+(y/5);*/
    }


    else{
        x=pow(bal+15,2);
        y=x;
    }

      //circle(x,y,rad);


      setfillstyle(SOLID_FILL,BLUE);
      floodfill(x,y,WHITE);




    getch();
    closegraph();
    return 0;
}
