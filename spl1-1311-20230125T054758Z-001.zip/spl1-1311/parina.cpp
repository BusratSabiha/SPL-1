#include<bits/stdc++.h>
using namespace std;
#include<graphics.h>



int main(void)
{

    int i;
     int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");

    setbkcolor(WHITE);
    cleardevice();






            setcolor(RED);
          circle(240,320,50);



          cleardevice();
           setcolor(BLUE);
           circle(240,320,50);

            cleardevice();






    getch();
    closegraph();
    return 0;
}


