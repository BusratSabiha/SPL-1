#include<bits/stdc++.h>
using namespace std;
#include<graphics.h>
#include<math.h>

struct node
{
    int p;
    int q;
};

int main(void)
{
    int n,i,x,y,rad=10,edge,j;

     printf("enter the number of node\n");
    scanf("%d",&n);

   struct node pos[n];

    int gd=DETECT,gm;
    initgraph(&gd,&gm,(char*)"");


    for(i=1; i<=n; i++)
    {

    if(i%2==0){x=pow(i+2,2);
    y=x*i;}

    else
    {
        x=pow(i+15,2);
        y=x;
    }

      circle(x,y,rad);
      setfillstyle(SOLID_FILL,WHITE);
      floodfill(x,y,WHITE);

      pos[i].p=x;
      pos[i].q=y;
    }

    printf("enter the number of edge\n");
    scanf("%d",&edge);

    for(j=0;j<edge;j++)
    {
        int l,m;
        printf("enter the connected node");
        scanf("%d",&l);
        scanf("%d",&m);
        line(pos[l].p,pos[l].q,pos[m].p,pos[m].q);
    }


    getch();
    closegraph();
    return 0;
}
